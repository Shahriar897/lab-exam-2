-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2018 at 07:10 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`name`, `email`, `username`, `password`, `gender`, `dob`) VALUES
('shahriar', 'shah@gmail.com', 'ss', 'ss', 'Male', '4/4/4444'),
('sabbir', 'shah@gmail.com', '', 'ss', 'Male', '4/1/1242'),
('sabbir', 'shah@gmail.com', '', 'ss', 'Male', '4/1/1242'),
('sabbir', 'shah@gmail.com', '', 'ss', 'Male', '4/1/1242'),
('sabbir', 'shah@gmail.com', 'shah', 'ss', 'Male', '14/44/1667'),
('sabbir', 'shah@gmail.com', 'shah', 'ss', 'Male', '14/44/1667'),
('agasd', 'shah@gmail.com', 'shah', 'ss', 'Male', '21/1/1455'),
('sasd', 'shah@gmail.com', 'shah', 'aa', 'Male', '12/2/1445');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
