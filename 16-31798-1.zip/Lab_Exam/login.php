<?php
	
	if(isset($_POST['login']))
	{//setcookie('name')
		$name       =	trim($_POST['name']);
		$pass       =	trim($_POST['pass']);
		$servername ="localhost";
		$username 	="root";
		$password 	="";
		$dbname 	="user";
		//setcookie('name',$name,time()+)
		$conn = mysqli_connect($servername, $username, $password, $dbname);
		
		if(!$conn)
		{
			die("Connection Error!".mysqli_connect_error());
		}
	/*	if($_SESSION["type"] == "Admin")
			header("Location: admin_home.html");
		if($_SESSION["type"] == "User")
				header("Location: user_home.html");
		
	if($_SESSION["userid"] == $name && $_SESSION["pass"] == $pass)
		{
			//echo $_SESSION["type"];
			if(($_SESSION["type"] == "Admin")
				header("Location: /SET-B/admin_home.html");
			else
				header("Location: /SET-B/user_home.html");
		}
	*/
	
		/*$name       =	trim($_POST['name']);
		$pass       =	trim($_POST['pass']);
		$servername ="localhost";
		$username 	="root";
		$password 	="";
		$dbname 	="user";
		*/
		
		
			$sql = "select * from user_info where name ='".$name."'";
			$result = mysqli_query($conn, $sql);
			
			if(mysqli_num_rows($result)>0)
			{
				$row=mysqli_fetch_assoc($result);
				if($row['password'] == $pass)
				{
					
						header("Location:loggedin_layout.html");
					
				}
				else
					echo "Error !!! Password doesn't match.";
			}
			else{
				echo "Error !!! User not found";
			}
		
		
		
		
		mysqli_close($conn);
		
	}
?>
<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method="POST">
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" name="pass"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="login">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>