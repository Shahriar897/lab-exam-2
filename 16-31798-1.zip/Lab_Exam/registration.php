<?php
if(isset($_POST['submit']))
	{
		$name       =	trim($_POST['name']);
		$email      =	trim($_POST['email']);
		$user		=	trim($_POST['user']);
		$ipass		=	trim($_POST['ipass']);
		$cpass  	=	trim($_POST['cpass']);
		$gender   	=	trim($_POST['gender']);
		$dd   		=	trim($_POST['dd']);
		$mm   		=	trim($_POST['mm']);
		$yy   		=	trim($_POST['yy']);
		$servername ="localhost";
		$username 	="root";
		$password 	="";
		$dbname 	="user";
		
		$conn = mysqli_connect($servername, $username, $password, $dbname);
		
		if(!$conn){
			die("Connection Error!".mysqli_connect_error());
		}
		if($ipass=="" or $cpass =="")
		{
			echo "Error !!! Please insert a Pasword ";
		}
		else
		{
			if($_POST['ipass'] == $_POST['cpass'])
			{
				$sql = "insert into user_info(name,email,username,password,gender,dob) values('".$name."','".$email."','".$user."','".$ipass."','".$gender."','".$dd."/".$mm."/".$yy."')";
				//echo $sql;
				if(mysqli_query($conn, $sql))
				{
					echo "<br/> Registration Complete";
				}
				else
				{
					echo "<br/> SQL Error".mysqli_error($conn);
				}
				
			}
			else 
				echo "Error !!! Pasword doesn't match";
			mysqli_close($conn);
			
		}
		
	}
?>
<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form action="#" method="POST">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text" ></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="user" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="ipass" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="cpass" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio" value="Male">Male
						<input name="gender" type="radio" value="Female">Female
						<input name="gender" type="radio" value="Other">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" name="dd" size="2" />/
						<input type="text" name="mm" size="2" />/
						<input type="text" name="yy" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" name="submit">
		<input type="reset">
	</form>
</fieldset>